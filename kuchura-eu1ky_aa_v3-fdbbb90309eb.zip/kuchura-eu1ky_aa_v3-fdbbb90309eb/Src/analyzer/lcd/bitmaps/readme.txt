The code uses 8BPP bitmaps converted to C array. There is a Python script, bmp2h.py, that converts all bitmaps found in this folder to appropriate C code. Just run it.
