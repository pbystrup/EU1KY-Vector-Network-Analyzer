/*
 *   (c) Yury Kuchura
 *   kuchura@gmail.com
 *
 *   This code can be used on terms of WTFPL Version 2 (http://www.wtfpl.net/).
 */

#ifndef _OSLCAL_H_
#define _OSLCAL_H_

void OSL_CalWnd(void);
void OSL_CalErrCorr(void);

#endif
