#ifndef _FFTWND_H
#define _FFTWND_H_

void FFTWND_Proc(void);

#endif // _FFTWND_H_

