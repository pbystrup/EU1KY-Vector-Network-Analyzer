#include "stm32746g_discovery.h"
#include "si5338a.h"
#include <math.h>

void SI5338A_Init(void)
{
}


void SI5338A_Off(void)
{
}


void SI5338A_SetF0(uint32_t fhz)
{
}


void SI5338A_SetLO(uint32_t fhz)
{
}
