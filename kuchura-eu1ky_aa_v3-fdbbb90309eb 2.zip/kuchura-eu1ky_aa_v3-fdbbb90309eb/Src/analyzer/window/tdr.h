/*
 *   (c) Yury Kuchura
 *   kuchura@gmail.com
 *
 *   This code can be used on terms of WTFPL Version 2 (http://www.wtfpl.net/).
 */

#ifndef TDR_H_
#define TDR_H_

void TDR_Proc(void);

#endif //TDR_H_
