/*
 *   (c) Yury Kuchura
 *   kuchura@gmail.com
 *
 *   This code can be used on terms of WTFPL Version 2 (http://www.wtfpl.net/).
 */

#ifndef BITMAPS_H_INCLUDED
#define BITMAPS_H_INCLUDED

//extern const unsigned char example_bmp[];
//extern const unsigned int example_bmp_size;
extern const unsigned char logo_bmp[];
extern const unsigned int logo_bmp_size;
#endif
